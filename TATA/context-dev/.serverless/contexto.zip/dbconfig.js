module.exports = {
	hostdb: 'mysql-15170-0.cloudclusters.net',
	portdb: 15170,
	databasedb: 'dbarce',
	userdb: 'arce',
	passworddb: '26426425'
}